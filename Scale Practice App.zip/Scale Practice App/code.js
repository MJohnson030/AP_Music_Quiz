 onEvent("homeStartButton", "click", function( ) {
  playSound("assets/category_app/app_interface_click_3.mp3", false);
  setScreen("categoryScreen");
});


//code for Scales Practice
onEvent("scalesCategoryButton", "click", function( ) {
  playSound("assets/category_app/app_interface_click_3.mp3", false);
  setScreen("scalesInstructionScreen");
});
  
  onEvent("scalesInstructionsBackButton", "click", function() {
   playSound("assets/category_app/app_interface_click_3.mp3", false);
   setScreen("categoryScreen");
});

onEvent("scalesContinueButton","click", function() {
  playSound("assets/category_app/app_interface_click_3.mp3", false);
   setScreen("scalesQuizScreen");
});



//Code for Bass clef Practice 
onEvent("bassClefCategoryButton", "click", function( ) {
  playSound("assets/category_app/app_interface_click_3.mp3", false);
  setScreen("bassInstructionScreen");
});

onEvent("bassInstructionsScreenBackButton", "click", function( ) {
   playSound("assets/category_app/app_interface_click_3.mp3", false);
   setScreen("categoryScreen");
});

onEvent("bassContinueButton", "click", function() {
  playSound("assets/category_app/app_interface_click_3.mp3", false);
  setScreen("bassQuizScreen");
});

//Code for Piano 
onEvent("pianoCategoryButton", "click", function( ) {
  playSound("assets/category_app/app_interface_click_3.mp3", false);
  setScreen("pianoInstructionScreen");
});

onEvent("pianoInstructionsBackButton", "click", function( ) {
   playSound("assets/category_app/app_interface_click_3.mp3", false);
   setScreen("categoryScreen");
});

//Code for Treble Clef Practice
onEvent("trebleClefCategoryButton", "click", function( ) {
  playSound("assets/category_app/app_interface_click_3.mp3", false);
  setScreen("trebleInstructionScreen");
});
  
  onEvent("trebleInstructionsBackButton", "click", function( ) {
   playSound("assets/category_app/app_interface_click_3.mp3", false);
   setScreen("categoryScreen");
});







//Abstraction

/* Assign 20 pictures to each practice quiz and give those ID's
an assigned value. If the answer is == the assigned value then add a point. 
If it isn't then take away a point. */


// var practiceQuestions = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
// var practiceQuestions = randomNumber(1, 20);
// function setQuestion(randomNumber(1, 20)) {

// }

